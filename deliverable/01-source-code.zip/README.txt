SMART GREENHOUSE — IoT Final (IAD591)
Viện Quản trị & Công nghệ FSB · Đại học FPT

Thành viên: Bùi Nguyễn Quốc Toàn · Mã Ngọc Long Bảo · Nguyễn Thị Hương ·
            Lê Nguyễn Gia Bảo · Phạm Xuân Thắng

=========================================================
NỘI DUNG
=========================================================
arduino/greenhouse/greenhouse.ino   Code Arduino: DHT22, LDR, LED, Servo (bit-bang),
                                    Buzzer chống cháy, LCD1602, gửi JSON qua HC-05/USB
arduino/servo_test/servo_test.ino   Sketch test servo riêng (debug)
rpi/app.py                          Flask + SQLite + đọc serial (Bluetooth ưu tiên, USB backup)
rpi/templates/index.html            Dashboard (dark UI, Chart.js)
rpi/telegram_notify.py              Gửi cảnh báo cháy qua Telegram (chỉ dùng stdlib urllib)
rpi/telegram_config.example.json    Mẫu cấu hình token/chat_id (copy -> telegram_config.json)
rpi/requirements.txt                Thư viện Python
sample_data/sensor_log_sample.csv   Log dữ liệu thật (minh chứng lưu trữ)

=========================================================
CÁCH CHẠY
=========================================================
1) ARDUINO
   - Mở arduino/greenhouse/greenhouse.ino trong Arduino IDE.
   - Cài thư viện: DHT sensor library, LiquidCrystal_I2C.
   - Nạp vào Arduino UNO (đấu nối theo wiring-diagram.png).

2) RASPBERRY PI
   cd rpi
   python3 -m venv venv && source venv/bin/activate
   pip install -r requirements.txt
   # (tuỳ chọn Telegram) cp telegram_config.example.json telegram_config.json  rồi điền token+chat_id
   python3 app.py
   - Mở dashboard: http://<IP-Pi>:5000

3) BLUETOOTH (HC-05)  — xem chi tiết trong 04-docs/BLUETOOTH_PLAYBOOK.md
   sudo rfcomm bind 0 <MAC-HC05>     # tạo /dev/rfcomm0
   - app.py ưu tiên /dev/rfcomm0, rớt BT thì tự fallback USB.

=========================================================
SƠ ĐỒ ĐẤU NỐI (chân)
=========================================================
DHT22=D2 · LDR=A0 · LED=D7 · Servo=D9 · Buzzer=D8 · LCD1602 I2C=A4/A5 · HC-05=D10/D11

Repo: https://github.com/bnqtoan/smart-greenhouse-iot
Hub:  https://bnqtoan.github.io/smart-greenhouse-iot/
